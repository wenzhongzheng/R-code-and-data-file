#=====================================================================================
#
#  Code chunk 1
#
#=====================================================================================
library(affy)
library(limma)
##import phenotype data
phenoData = read.AnnotatedDataFrame('C:/Users/wenzh/Desktop/WGCNA AZM/target.txt')
pheno = pData(phenoData)
View(pheno)
#import Annotaion
anno = read.csv("C:/Users/wenzh/Desktop/WGCNA AZM/Annotation.csv",head=T)
View(head(anno))
##RMA normalization
#eset.rma = RMA(Data)
eset.rma <- justRMA(filenames=paste(rownames(pheno),'.CEL',sep=''), celfile.path='C:/Users/wenzh/Desktop/WGCNA AZM/CEL')
datExpr = exprs(eset.rma)
#Supplemental missing value
library(impute)
#Calculation of missing values by KNN method
imputed_gene_exp = impute.knn(datExpr,k=10,rowmax = 0.5,
                              colmax=0.8,maxp =3000, rng.seed=362436069)
datExpr2 = imputed_gene_exp$data

#=====================================================================================
#
#  Code chunk 1
#
#=====================================================================================
## Batch effect (sva--combat)
library(sva)
library(pamr)
batch = pheno[,c('batch')]
batch
modcombat = model.matrix(~1,data=pheno)
combat_edata = ComBat(dat=datExpr2,batch=batch,
                      mod=modcombat,par.prior=T,
                      prior.plot=T)
write.table(combat_edata,file="Expdata.txt",sep="\t")
